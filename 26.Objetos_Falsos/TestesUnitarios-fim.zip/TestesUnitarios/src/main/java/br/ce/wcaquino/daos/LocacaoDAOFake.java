package br.ce.wcaquino.daos;

import br.ce.wcaquino.entidades.Locacao;

public class LocacaoDAOFake implements LocacaoDAO {

	public void salvar(Locacao locacao) {

	}

}
