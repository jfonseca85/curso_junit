package br.ce.wcaquino.exceptions;

public class NaoPodeDividirPorZeroException extends Exception {

	private static final long serialVersionUID = 7199045573572505549L;

}
