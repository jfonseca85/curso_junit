package br.ce.wcaquino.servicos;

import java.util.Date;

public class TimerService {

	public Date getDataAtual(){
		return new Date();
	}
}
