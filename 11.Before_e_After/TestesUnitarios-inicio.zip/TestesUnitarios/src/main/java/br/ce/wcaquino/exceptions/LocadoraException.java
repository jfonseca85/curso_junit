package br.ce.wcaquino.exceptions;

public class LocadoraException extends Exception {

	private static final long serialVersionUID = 3837982804180390821L;

	public LocadoraException(String message) {
		super(message);
	}
}
